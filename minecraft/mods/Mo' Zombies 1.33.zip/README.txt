######README NOW######
1.Version
2.Installing Client
3.Installing Server
4.Credits


######Version######
Client: 1.33
Server: 0.7

######Installing Client######
1. Download the Mo' Zombies.zip file and extract the contents.
2. Open the minecraft.jar with winrar or 7z and delete the META_INF folder
3. Paste all the files in the zip to the jar
4. Close the minecraft.jar
5. Load up Minecraft and try not to die.

######Installing Server######
0.5. Install the Mo' Zombies Client mod to minecraft.jar
1.Download The minecraft_server.jar from http://www.minecraft.net/download/
2. Download Mo' Zombies Multiplayer.zip
3. Open the minecraft_server.jar with winrar or 7z
4. Copy the files from the zip to the server jar
5. DO NOT DELETE META-INF
6. Close server jar and start the server like a normal minecraft server

######Extra Credits######
To http://www.youtube.com/user/theviewermarcus for helping me texture the pirate and the cape
To minecraftskins.com for some of the skins
To Planet Minecraft for helping me with some of the skins
To The guys at #MCP-Modding for putting up with my questions